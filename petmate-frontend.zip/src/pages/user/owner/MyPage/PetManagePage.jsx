import React from "react";

function PetManagePage() {

    return(
        <>
        반려동물 목록관리 페이지
        </>
    );
}

export default PetManagePage;