// src/pages/petowner/manage/PetManagePage.jsx
import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Calendar, Heart } from 'lucide-react';
import './PetManagePage.css';
import { useAuth } from '../../../../contexts/AuthContext';
import { apiRequest } from '../../../../services/api';

const PetManagePage = () => {
  const { user, isLogined } = useAuth();
  const [pets, setPets] = useState([]);
  const [breeds, setBreeds] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingPet, setEditingPet] = useState(null);
  const [loading, setLoading] = useState(false);

  // 로컬 목데이터 유지
  const mockBreeds = [
    { id: 1, name: '골든 리트리버', species: 'D' },
    { id: 2, name: '러시안 블루', species: 'C' },
    { id: 3, name: '시베리안 허스키', species: 'D' },
    { id: 4, name: '페르시안', species: 'C' },
    { id: 5, name: '믹스', species: 'D' },
    { id: 6, name: '코리안 숏헤어', species: 'C' },
    { id: 7, name: '네덜란드 드워프', species: 'R' },
    { id: 8, name: '햄스터', species: 'S' },
    { id: 9, name: '앵무새', species: 'B' },
    { id: 10, name: '도마뱀', species: 'P' },
  ];

  useEffect(() => {
    if (!isLogined) return;
    setBreeds(mockBreeds);
    loadMyPets();

    // ---- 임시 테스트 호출: 품종 API 콘솔 출력 ----
    (async () => {
      try {
        const { data } = await apiRequest.get('/pet/breeds', { params: { species: 'D' } });
        console.log('[TEST] /pet/breeds?species=D ->', data);
      } catch (e) {
        console.warn('[TEST] /pet/breeds 호출 실패:', e?.response?.data || e.message);
      }
    })();
    // -------------------------------------------
  }, [isLogined]);

  const loadMyPets = async () => {
    try {
      setLoading(true);
      setPets([
        {
          id: 1,
          ownerUserId: 1,
          name: '멍멍이',
          imageUrl: '/uploads/pets/dog1.jpg',
          species: 'D',
          breedId: 1,
          breedName: '골든 리트리버',
          gender: 'M',
          ageYear: 3.5,
          weightKg: 25.5,
          neutered: 1,
          temper: '활발하고 친근함',
          note: '사람을 매우 좋아',
          createdAt: '2024-01-15T10:30:00',
        },
        {
          id: 2,
          ownerUserId: 1,
          name: '야옹이',
          imageUrl: '/uploads/pets/cat1.jpg',
          species: 'C',
          breedId: 2,
          breedName: '러시안 블루',
          gender: 'F',
          ageYear: 2.0,
          weightKg: 4.2,
          neutered: 1,
          temper: '조용하고 독립적',
          note: '혼자를 선호',
          createdAt: '2024-03-20T14:20:00',
        },
      ]);
    } catch (e) {
      console.error('펫 목록 로드 실패:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const on = showAddModal || !!editingPet;
    if (on) document.body.classList.add('modal-open');
    else document.body.classList.remove('modal-open');
    return () => document.body.classList.remove('modal-open');
  }, [showAddModal, editingPet]);

  const handleAddPet = async (petData) => {
    if (!isLogined || !user) {
      alert('로그인이 필요합니다.');
      return;
    }
    try {
      setLoading(true);
      const requestData = {
        name: petData.name,
        imageUrl: petData.imageUrl || null,
        species: petData.species,
        breedId: petData.breedId || null,
        gender: petData.gender,
        ageYear: petData.ageYear || null,
        weightKg: petData.weightKg || null,
        neutered: petData.neutered,
        temper: petData.temper || null,
        note: petData.note || null,
      };

      const { data: savedPet } = await apiRequest.post('/api/pets', requestData);

      const petWithBreedName = {
        ...savedPet,
        breedName: breeds.find((b) => b.id === savedPet.breedId)?.name || '',
      };

      setPets((prev) => [...prev, petWithBreedName]);
      setShowAddModal(false);
      alert('반려동물이 성공적으로 등록되었습니다.');
    } catch (error) {
      console.error('펫 등록 실패:', error);
      const msg = error?.response?.data?.message || error?.message || '알 수 없는 오류';
      alert(`펫 등록 실패: ${msg}`);
    } finally {
      setLoading(false);
    }
  };

  const handleEditPet = async (petData) => {
    try {
      setPets((prev) =>
        prev.map((p) =>
          p.id === editingPet.id
            ? {
                ...p,
                ...petData,
                breedName: breeds.find((b) => b.id === petData.breedId)?.name || '',
              }
            : p
        )
      );
      setEditingPet(null);
    } catch (error) {
      console.error('펫 수정 실패:', error);
      alert('펫 정보 수정에 실패했습니다.');
    }
  };

  const handleDeletePet = async (petId) => {
    if (!window.confirm('정말로 삭제하시겠습니까?')) return;
    try {
      setPets((prev) => prev.filter((p) => p.id !== petId));
    } catch (error) {
      console.error('펫 삭제 실패:', error);
      alert('펫 정보 삭제에 실패했습니다.');
    }
  };

  const getSpeciesText = (species) =>
    ({
      D: '강아지',
      C: '고양이',
      R: '토끼',
      S: '설치류',
      H: '말',
      B: '새',
      P: '파충류',
      F: '가축동물',
      O: '기타',
    }[species] || species);

  const getGenderText = (gender) => (gender === 'M' ? '남성' : '여성');
  const formatDate = (s) => new Date(s).toLocaleDateString('ko-KR');

  if (!isLogined) {
    return (
      <div className="pet-manage-page">
        <div className="pet-manage-container">
          <div className="pet-manage-empty">
            <Heart size={64} className="pet-manage-empty-icon" />
            <h3 className="pet-manage-empty-title">로그인이 필요합니다</h3>
            <p className="pet-manage-empty-desc">반려동물 관리를 위해 로그인해주세요.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pet-manage-page">
      <div className="pet-manage-container">
        <div className="pet-manage-header">
          <div className="pet-manage-header-info">
            <h1 className="pet-manage-title">내 반려동물 관리</h1>
            <p className="pet-manage-subtitle">등록된 반려동물: {pets.length}마리</p>
          </div>
          <button onClick={() => setShowAddModal(true)} className="pet-manage-add-btn">
            <Plus size={20} />
            반려동물 등록
          </button>
        </div>

        {pets.length === 0 ? (
          <div className="pet-manage-empty">
            <Heart size={64} className="pet-manage-empty-icon" />
            <h3 className="pet-manage-empty-title">등록된 반려동물이 없습니다</h3>
            <p className="pet-manage-empty-desc">첫 번째 반려동물을 등록해보세요!</p>
          </div>
        ) : (
          <div className="pet-manage-grid">
            {pets.map((pet) => (
              <div key={pet.id} className="pet-card">
                <div className="pet-card-image-container">
                  <img
                    src={pet.imageUrl || '/api/placeholder/300/200'}
                    alt={pet.name}
                    className="pet-card-image"
                  />
                  <div className="pet-card-actions">
                    <button
                      onClick={() => setEditingPet(pet)}
                      className="pet-card-action-btn pet-card-edit-btn"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button
                      onClick={() => handleDeletePet(pet.id)}
                      className="pet-card-action-btn pet-card-delete-btn"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="pet-card-content">
                  <div className="pet-card-header">
                    <h3 className="pet-card-name">{pet.name}</h3>
                    <span className="pet-card-species">{getSpeciesText(pet.species)}</span>
                  </div>

                  <div className="pet-card-info">
                    <div className="pet-card-info-row">
                      <span>품종:</span>
                      <span className="pet-card-info-value">{pet.breedName}</span>
                    </div>
                    <div className="pet-card-info-row">
                      <span>나이:</span>
                      <span className="pet-card-info-value">{pet.ageYear}살</span>
                    </div>
                    <div className="pet-card-info-row">
                      <span>성별:</span>
                      <span className="pet-card-info-value">{getGenderText(pet.gender)}</span>
                    </div>
                    <div className="pet-card-info-row">
                      <span>체중:</span>
                      <span className="pet-card-info-value">{pet.weightKg}kg</span>
                    </div>
                    <div className="pet-card-info-row">
                      <span>중성화:</span>
                      <span className="pet-card-info-value">{pet.neutered ? '완료' : '미완료'}</span>
                    </div>
                  </div>

                  {pet.temper && (
                    <div className="pet-card-temper">
                      <div className="pet-card-temper-label">성격</div>
                      <div className="pet-card-temper-value">{pet.temper}</div>
                    </div>
                  )}

                  {pet.note && (
                    <div className="pet-card-note">
                      <div className="pet-card-note-label">특이사항</div>
                      <p className="pet-card-note-text">{pet.note}</p>
                    </div>
                  )}

                  <div className="pet-card-date">
                    <Calendar size={12} />
                    등록일: {formatDate(pet.createdAt)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {(showAddModal || editingPet) && (
          <PetModal
            pet={editingPet}
            breeds={breeds}
            loading={loading}
            onSave={editingPet ? handleEditPet : handleAddPet}
            onClose={() => {
              setShowAddModal(false);
              setEditingPet(null);
            }}
          />
        )}
      </div>
    </div>
  );
};

const PetModal = ({ pet, breeds, loading, onSave, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    imageUrl: '',
    species: 'D',
    breedId: '',
    gender: 'M',
    ageYear: '',
    weightKg: '',
    neutered: 0,
    temper: '',
    note: '',
  });

  const [filteredBreeds, setFilteredBreeds] = useState([]);

  useEffect(() => {
    if (pet) {
      setFormData({
        name: pet.name || '',
        imageUrl: pet.imageUrl || '',
        species: pet.species || 'D',
        breedId: pet.breedId || '',
        gender: pet.gender || 'M',
        ageYear: pet.ageYear || '',
        weightKg: pet.weightKg || '',
        neutered: pet.neutered || 0,
        temper: pet.temper || '',
        note: pet.note || '',
      });
    }
  }, [pet]);

  // ---- 임시방편: species 바뀔 때마다 서버 품종 API 호출 + 콘솔 출력 ----
  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const { data } = await apiRequest.get('/pet/breeds', { params: { species: formData.species } });
        console.log(`[TEST] /pet/breeds?species=${formData.species} ->`, data);
        if (!ignore) setFilteredBreeds(Array.isArray(data) ? data : []);
      } catch (e) {
        console.warn(`[TEST] /pet/breeds 실패(${formData.species}):`, e?.response?.data || e.message);
        // 실패 시 기존 mock으로 폴백
        const fb = breeds.filter((b) => b.species === formData.species);
        if (!ignore) setFilteredBreeds(fb);
      }
    })();
    return () => { ignore = true; };
  }, [formData.species, breeds]);
  // --------------------------------------------------------------------

  useEffect(() => {
    if (formData.breedId && !filteredBreeds.find((b) => b.id === Number(formData.breedId))) {
      setFormData((prev) => ({ ...prev, breedId: '' }));
    }
  }, [filteredBreeds, formData.breedId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert('펫 이름을 입력해주세요.');
      return;
    }
    if (!formData.breedId) {
      alert('품종을 선택해주세요.');
      return;
    }
    const submitData = {
      ...formData,
      breedId: Number(formData.breedId),
      ageYear: parseFloat(formData.ageYear) || 0,
      weightKg: parseFloat(formData.weightKg) || 0,
      neutered: Number(formData.neutered),
    };
    onSave(submitData);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="pet-modal-overlay">
      <div className="pet-modal">
        <div className="pet-modal-header">
          <h2 className="pet-modal-title">{pet ? '반려동물 정보 수정' : '새 반려동물 등록'}</h2>
        </div>

        <div className="pet-modal-content">
          <div className="pet-form-grid">
            <div className="pet-form-group">
              <label className="pet-form-label">이름 *</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="pet-form-input"
                placeholder="반려동물 이름"
                required
              />
            </div>

            <div className="pet-form-group">
              <label className="pet-form-label">동물 종류 *</label>
              <select
                name="species"
                value={formData.species}
                onChange={handleChange}
                className="pet-form-select"
              >
                <option value="D">강아지</option>
                <option value="C">고양이</option>
                <option value="R">토끼</option>
                <option value="S">설치류</option>
                <option value="H">말</option>
                <option value="B">새</option>
                <option value="P">파충류</option>
                <option value="F">가축동물</option>
                <option value="O">기타</option>
              </select>
            </div>

            <div className="pet-form-group">
              <label className="pet-form-label">품종 *</label>
              <select
                name="breedId"
                value={formData.breedId}
                onChange={handleChange}
                className="pet-form-select"
                required
              >
                <option value="">품종을 선택하세요</option>
                {filteredBreeds.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="pet-form-group">
              <label className="pet-form-label">성별 *</label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="pet-form-select"
              >
                <option value="M">남성</option>
                <option value="F">여성</option>
              </select>
            </div>

            <div className="pet-form-group">
              <label className="pet-form-label">나이 (년)</label>
              <input
                type="number"
                step="0.1"
                name="ageYear"
                value={formData.ageYear}
                onChange={handleChange}
                className="pet-form-input"
                placeholder="3.5"
                min="0"
                max="30"
              />
            </div>

            <div className="pet-form-group">
              <label className="pet-form-label">체중 (kg)</label>
              <input
                type="number"
                step="0.1"
                name="weightKg"
                value={formData.weightKg}
                onChange={handleChange}
                className="pet-form-input"
                placeholder="5.2"
                min="0"
              />
            </div>
          </div>

          <div className="pet-form-group">
            <label className="pet-form-label">이미지 URL</label>
            <input
              type="text"
              name="imageUrl"
              value={formData.imageUrl}
              onChange={handleChange}
              className="pet-form-input"
              placeholder="/uploads/pets/my-pet.jpg"
            />
          </div>

          <div className="pet-form-group">
            <label className="pet-form-label">중성화 여부</label>
            <select
              name="neutered"
              value={formData.neutered}
              onChange={handleChange}
              className="pet-form-select"
            >
              <option value={0}>미완료</option>
              <option value={1}>완료</option>
            </select>
          </div>

          <div className="pet-form-group">
            <label className="pet-form-label">성격</label>
            <input
              type="text"
              name="temper"
              value={formData.temper}
              onChange={handleChange}
              className="pet-form-input"
              placeholder="활발함, 온순함 등"
            />
          </div>

          <div className="pet-form-group">
            <label className="pet-form-label">특이사항</label>
            <textarea
              name="note"
              value={formData.note}
              onChange={handleChange}
              rows={4}
              className="pet-form-textarea"
              placeholder="알레르기, 질병 이력 등"
            />
          </div>

          <div className="pet-modal-actions">
            <button type="button" onClick={onClose} className="pet-modal-btn pet-modal-cancel-btn">
              취소
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="pet-modal-btn pet-modal-submit-btn"
              disabled={loading}
            >
              {loading ? '등록 중...' : pet ? '수정하기' : '등록하기'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PetManagePage;
