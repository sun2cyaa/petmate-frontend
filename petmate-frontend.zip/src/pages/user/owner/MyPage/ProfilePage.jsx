import React from "react";

function ProfilePage() {

    return(
        <>
        프로필 보기, 조회 페이지
        </>
    );
}

export default ProfilePage;