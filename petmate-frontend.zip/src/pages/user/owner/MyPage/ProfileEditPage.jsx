import React from "react";

function ProfileEditPage() {

    return(
        <>
        프로필 수정 페이지
        </>
    );
}

export default ProfileEditPage;