import React from "react";

function PetRegisterPage() {
    
    return(
        <>
        반려동물 등록 페이지
        </>
    );
}

export default PetRegisterPage;