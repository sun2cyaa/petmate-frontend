import React from "react";

function CompanyDetailModal() {
    return(
        <div>




        </div>
    );
}

export default CompanyDetailModal;