function Notice() {
    return (
      <div style={{ padding: "80px", textAlign: "center" }}>
        <h2>공지사항</h2>
        <p>공지사항 페이지는 준비 중입니다</p>
      </div>
    );
  }
  export default Notice;
  