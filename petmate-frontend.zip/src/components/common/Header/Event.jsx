function Event() {
    return (
      <div style={{ padding: "40px" }}>
        <h1>이벤트</h1>
        <p>현재 진행 중인 이벤트가 없습니다.</p>
      </div>
    );
  }
  
  export default Event;
  