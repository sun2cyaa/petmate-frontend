import "../styles/SectionTitle.css";

export default function SectionTitle({ title }) {
  return (
    <h2 className="sectiontitle-title">{title}</h2>
  );
}
